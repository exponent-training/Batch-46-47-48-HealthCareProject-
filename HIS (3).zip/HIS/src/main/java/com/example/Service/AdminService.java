package com.example.Service;

public interface AdminService {

	public void assignRoleToUser(String email, String rolename);
}
