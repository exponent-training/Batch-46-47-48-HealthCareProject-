package com.example.Service;

import com.example.Entity.Roles;

public interface RoleService {

	public void AddRolesInService(Roles role);
}
