package com.example.Service;

import com.example.DTO.LoginDetailsDTO;
import com.example.DTO.Response;
import com.example.Entity.Login;

public interface LoginService {

	public LoginDetailsDTO LoginInService(Login login);

	public Response forgetpasswordinService(Login login);

}
