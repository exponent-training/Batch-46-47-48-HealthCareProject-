package com.example.DTO;

import lombok.Data;

@Data
public class LoginDetailsDTO {

	private String firstName;

	private String lastName;

	private String Cnt;

	private String msg;

}
