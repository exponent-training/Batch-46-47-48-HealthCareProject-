package com.example.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Type;

import lombok.Data;

@Entity
@Data
public class User {

	// 1 , 2 -> 53660
	//

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;

	// Task.
	// todays date 04-01-2025 (any 4 digits) -> generate. -> 412025858
	private String userNumber;

	private String firstName;

	private String lastName;

	private String gender;

	private String mobnumber;

	private String address;

	private String zipcode;

	private String cnt;

	@OneToOne(cascade = CascadeType.DETACH)
	private Roles role;

	@Type(type = "yes_no")
	private boolean status;

}
