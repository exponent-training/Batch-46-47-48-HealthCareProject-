package com.example.Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class UserNumberGenerator {

	public static String numberGenertor() {
//		Date , 4 digit

//		25 01 04  yyMMdd

		LocalDateTime ldt = LocalDateTime.now();

		DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("yyMMdd");

		String pattern = ldt.format(ofPattern);

		Random random = new Random();

		int fourDigitRandomnum = random.nextInt(9999) + 1000;

		System.out.println(fourDigitRandomnum);

		String un = pattern + fourDigitRandomnum;

		return un;

	}
}
