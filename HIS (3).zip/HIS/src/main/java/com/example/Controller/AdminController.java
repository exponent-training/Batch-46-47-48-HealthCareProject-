package com.example.Controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.AdminService;

@RestController
@RequestMapping("/exponent/admin")
public class AdminController {

	@Autowired
	private AdminService as;

	@PostMapping("/roleassign/{email}/{rolename}")
	public void assignRole(@PathVariable String email, @PathVariable String rolename) {

		as.assignRoleToUser(email, rolename);

	}
}
