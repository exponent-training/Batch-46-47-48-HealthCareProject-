package com.example.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.DTO.LoginDetailsDTO;
import com.example.DTO.Response;
import com.example.Entity.Login;
import com.example.Service.LoginService;

@RestController
@RequestMapping("/exponent/user")
public class LoginContoller {

	@Autowired
	private LoginService ls;

	@GetMapping("/login")
	public ResponseEntity<?> userLogin(@RequestBody Login login) {

		LoginDetailsDTO ldd = ls.LoginInService(login);

		return new ResponseEntity(ldd, HttpStatus.OK);
	}

	@PutMapping("/forgetpassword")
	public ResponseEntity<Response> forgetPassword(@RequestBody Login login) {
		Response responseDTO = ls.forgetpasswordinService(login);

		return new ResponseEntity<Response>(responseDTO, HttpStatus.OK);

	}

}
