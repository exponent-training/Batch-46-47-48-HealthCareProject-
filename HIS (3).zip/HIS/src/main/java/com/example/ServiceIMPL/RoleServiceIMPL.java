package com.example.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.Roles;
import com.example.Repo.RoleRepo;
import com.example.Service.RoleService;

@Service
public class RoleServiceIMPL implements RoleService {

	@Autowired
	private RoleRepo rr;

	@Override
	public void AddRolesInService(Roles role) {

//		doctor.

		if (role != null) {

			Roles dbRole = rr.findByRoleName(role.getRoleName());

			if (dbRole == null) {

				rr.save(role);
				System.out.println("Role Addedd!!!");

			} else {

				System.out.println("Role Alreday Exist");
			}

		} else {
			System.out.println("Role is Invalid");
		}

	}

}
