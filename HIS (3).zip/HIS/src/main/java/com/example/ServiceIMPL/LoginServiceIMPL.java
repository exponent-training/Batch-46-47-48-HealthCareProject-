package com.example.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.LoginDetailsDTO;
import com.example.DTO.Response;
import com.example.Entity.Login;
import com.example.Repo.LoginRepo;
import com.example.Service.LoginService;

@Service
public class LoginServiceIMPL implements LoginService {

	@Autowired
	private LoginRepo lr;

	@Override
	public LoginDetailsDTO LoginInService(Login login) {

//		email and password.

		LoginDetailsDTO ldd = new LoginDetailsDTO();

		Login loginDetails = lr.findByEmailAndPassword(login.getEmail(), login.getPassword());
//		check list :- 1. email not empty.
//		              2. cred invalid.
//		              3. status T -> login
		
		
		//bydefault -> role patient-> login
		if (login.getEmail() != null) {

			if (loginDetails != null) {

				if (loginDetails.getUser().isStatus()) {

					ldd.setFirstName(loginDetails.getUser().getFirstName());
					ldd.setLastName(loginDetails.getUser().getLastName());
					ldd.setCnt(loginDetails.getUser().getCnt());

					return ldd;

				} else {

					ldd.setMsg("Your status is inactive contact to admin!!!");

					return ldd;
				}

			} else {
				ldd.setMsg("Cred invalid.");
				return ldd;
			}

		} else {
			ldd.setMsg("Email Is EMpty");
			return ldd;
		}

	}

	@Override
	public Response forgetpasswordinService(Login login) {

		if (login.getEmail() != null) {
			Login originallogin = lr.findByEmail(login.getEmail());

			if (originallogin != null) {

				originallogin.setPassword(login.getPassword());

				lr.save(originallogin);

				return Response.builder().msg("Password Updated!!!").build();

			} else {

				return Response.builder().msg("email doesnot exist").build();
			}

		} else {

			return Response.builder().msg("Email is Empty").build();

		}

	}

}
