package com.example.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.Login;
import com.example.Entity.Roles;
import com.example.Entity.User;
import com.example.Repo.LoginRepo;
import com.example.Repo.RoleRepo;
import com.example.Repo.UserRepo;
import com.example.Service.AdminService;

@Service
public class AdminServiceIMPL implements AdminService {

	@Autowired
	private LoginRepo lr;

	@Autowired
	private RoleRepo rr;

	@Autowired
	private UserRepo ur;

	@Override
	public void assignRoleToUser(String email, String rolename) {

		Login dbLogin = lr.findByEmail(email);
		Roles dbRole = rr.findByRoleName(rolename);
		if (dbLogin != null) {

			if (dbRole != null) {

				if (dbLogin.getEmail().equals(email)) {

					User user = dbLogin.getUser();

					user.setRole(dbRole);
					ur.save(user);

					System.out.println("Role Assigen");

				} else {
					System.out.println("Email Invalid");
				}
			} else {
				System.out.println("Role Does not exist  , contact to admin");
			}

		} else {
			System.out.println("Email is EMpty");
		}

	}

}
