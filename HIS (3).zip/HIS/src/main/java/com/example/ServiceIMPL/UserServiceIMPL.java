package com.example.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.Response;
import com.example.Entity.Login;
import com.example.Repo.LoginRepo;
import com.example.Repo.UserRepo;
import com.example.Service.UserService;
import com.example.Util.UserNumberGenerator;

@Service
public class UserServiceIMPL implements UserService {

	@Autowired
	private UserRepo ur;

	@Autowired
	private LoginRepo lr;

	@Override
	public Response registerUserinService(Login login) {

//		login (email,password) -> user
//		registrations -> 

//		1. login and user null X.
//		2. email not empty X
//		3. already present. 

		// admin@gmail.com

		Login userdetail = lr.findByEmail(login.getEmail());

		if (login != null && login.getUser() != null) {

			if (login.getEmail() != null) {

				if (userdetail == null) {
// 
					String num = UserNumberGenerator.numberGenertor();
					login.getUser().setUserNumber(num);
					lr.save(login);

					return Response.builder().msg("Details Registerd sucessfully!!!").build();

				} else {
					return Response.builder().msg("User already regesterd!!!").build();
				}

			} else {

				return Response.builder().msg("Email is EMpty").build();
			}

		} else {
			return Response.builder().msg("User not found").build();
		}
	}

}
