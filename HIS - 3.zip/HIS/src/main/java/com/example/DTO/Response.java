package com.example.DTO;

import lombok.Data;

@Data
public class Response {

	private String msg;

}
