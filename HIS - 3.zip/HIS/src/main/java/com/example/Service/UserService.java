package com.example.Service;

import com.example.DTO.Response;
import com.example.Entity.Login;

public interface UserService {

	public Response registerUserinService(Login login);

}
