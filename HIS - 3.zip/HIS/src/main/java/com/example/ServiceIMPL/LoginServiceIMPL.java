package com.example.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.LoginDetailsDTO;
import com.example.Entity.Login;
import com.example.Repo.LoginRepo;
import com.example.Service.LoginService;

@Service
public class LoginServiceIMPL implements LoginService {

	@Autowired
	private LoginRepo lr;

	@Override
	public LoginDetailsDTO LoginInService(Login login) {

//		email and password.

		LoginDetailsDTO ldd = new LoginDetailsDTO();

		Login loginDetails = lr.findByEmailAndPassword(login.getEmail(), login.getPassword());
//		check list :- 1. email not empty.
//		              2. cred invalid.
//		              3. status T -> login
		if (login.getEmail() != null) {

			if (loginDetails != null) {

				if (loginDetails.getUser().isStatus()) {

					ldd.setFirstName(loginDetails.getUser().getFirstName());
					ldd.setLastName(loginDetails.getUser().getLastName());
					ldd.setCnt(loginDetails.getUser().getCnt());

					return ldd;

				} else {

					ldd.setMsg("Your status is inactive contact to admin!!!");

					return ldd;
				}

			} else {
				ldd.setMsg("Cred invalid.");
				return ldd;
			}

		} else {
			ldd.setMsg("Email Is EMpty");
			return ldd;
		}

	}

}
