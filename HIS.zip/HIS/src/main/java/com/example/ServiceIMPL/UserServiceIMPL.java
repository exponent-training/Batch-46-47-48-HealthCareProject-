package com.example.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.User;
import com.example.Repo.UserRepo;
import com.example.Service.UserService;
import com.example.Util.UserNumberGenerator;

@Service
public class UserServiceIMPL implements UserService {

	@Autowired
	private UserRepo ur;

	@Override
	public void registerUserinService(User user) {

		if (user != null && user.getEmail() != null) {

			String un = UserNumberGenerator.numberGenertor();

			user.setUserNumber(un);

			ur.save(user);

		} else {
			System.out.println("Email is Empty");
		}

	}

}
