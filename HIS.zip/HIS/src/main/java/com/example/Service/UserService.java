package com.example.Service;

import com.example.Entity.User;

public interface UserService {

	public void registerUserinService(User user);

}
